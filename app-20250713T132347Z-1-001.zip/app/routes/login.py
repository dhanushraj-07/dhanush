from fastapi import APIRouter, HTTPException
from app.models.login_model import LoginRequest
from app.driver import initialize_driver
from app.utils import wait_for_element
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

router = APIRouter()

@router.post("/login")
async def login(request: LoginRequest):
    driver = initialize_driver()
    driver.get("https://www.linkedin.com/login")

    username_field = wait_for_element(driver, By.ID, "username")
    password_field = wait_for_element(driver, By.ID, "password")
    sign_in_button = wait_for_element(driver, By.CSS_SELECTOR, "button[type='submit']")

    if not username_field or not password_field or not sign_in_button:
        raise HTTPException(status_code=500, detail="Login elements not found.")

    username_field.send_keys(request.username)
    password_field.send_keys(request.password)
    sign_in_button.click()

    WebDriverWait(driver, 10).until(EC.url_contains("feed"))
    return {"message": "Logged in successfully."}
