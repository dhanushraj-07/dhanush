from fastapi import APIRouter, HTTPException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from app.driver import get_driver
from app.utils import find_element_safely, click_element_safely
from app.models.connect_model import ConnectRequest
import logging

router = APIRouter()

@router.post("/connect")
async def connect_profile(request: ConnectRequest):
    driver = get_driver()
    if driver is None:
        raise HTTPException(status_code=400, detail="Browser session not initialized. Please /login first.")

    try:
        logging.info(f"Navigating to profile: {request.profile_url}")
        driver.get(request.profile_url)

        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "h1.text-heading-xlarge"))
        )

        # Check for Connect button
        connect_btn_xpath = "//button[contains(text(), 'Connect') or contains(text(), 'Invite to Connect')]"
        connect_button = find_element_safely(driver, By.XPATH, connect_btn_xpath)

        if connect_button:
            logging.info("Found 'Connect' button directly.")
