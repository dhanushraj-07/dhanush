from fastapi import APIRouter
from app.driver import close_driver

router = APIRouter()

@router.get("/close")
async def close():
    close_driver()
    return {"message": "Browser session closed."}
