from fastapi import APIRouter, HTTPException
from app.driver import get_driver
from app.utils import wait_for_element, find_element_safely, click_element_safely
from app.models.check_model import CheckConnectionRequest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import logging
import time

router = APIRouter()

@router.post("/check_connection")
async def check_connection_and_message(request: CheckConnectionRequest):
    driver = get_driver()
    if driver is None:
        raise HTTPException(status_code=400, detail="Browser session not initialized. Please /login first.")

    try:
        logging.info(f"Navigating to profile: {request.profile_url}")
        driver.get(request.profile_url)

        WebDriverWait(driver, 15).unt
