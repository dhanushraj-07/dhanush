from pydantic import BaseModel

class ConnectRequest(BaseModel):
    profile_url: str
