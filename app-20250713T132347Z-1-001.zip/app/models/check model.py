from pydantic import BaseModel

class CheckConnectionRequest(BaseModel):
    profile_url: str
    message: str
